/*
 Navicat MySQL Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80026
 Source Host           : localhost:3306
 Source Schema         : db_courseselect

 Target Server Type    : MySQL
 Target Server Version : 80026
 File Encoding         : 65001

 Date: 24/07/2021 10:32:44
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for t_adminlogon
-- ----------------------------
DROP TABLE IF EXISTS `t_adminlogon`;
CREATE TABLE `t_adminlogon` (
  `adminID` int NOT NULL DEFAULT '10',
  `password` int NOT NULL,
  PRIMARY KEY (`adminID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of t_adminlogon
-- ----------------------------
BEGIN;
INSERT INTO `t_adminlogon` VALUES (666, 123456);
COMMIT;

-- ----------------------------
-- Table structure for t_course
-- ----------------------------
DROP TABLE IF EXISTS `t_course`;
CREATE TABLE `t_course` (
  `courseID` int NOT NULL,
  `courseName` varchar(10) NOT NULL,
  `courseTeacher` varchar(5) NOT NULL,
  `courseTime` varchar(10) NOT NULL,
  `capacity` int NOT NULL,
  `numSelected` int DEFAULT NULL,
  PRIMARY KEY (`courseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of t_course
-- ----------------------------
BEGIN;
INSERT INTO `t_course` VALUES (1, '金庸小说研究', '老金', '周四九、十节', 45, NULL);
INSERT INTO `t_course` VALUES (2, '九型人格', '老九', '周四九、十节', 35, NULL);
INSERT INTO `t_course` VALUES (3, '剧本写作基础', '老本', '周四九、十节', 40, NULL);
INSERT INTO `t_course` VALUES (4, '女子礼仪', '老女', '周四九、十节', 40, NULL);
INSERT INTO `t_course` VALUES (5, '男德', '老男', '周四九、十节', 66, NULL);
INSERT INTO `t_course` VALUES (6, '人工智能', '老人', '周四九、十节', 80, NULL);
INSERT INTO `t_course` VALUES (7, '生命科学', '老生', '周四九、十节', 120, NULL);
COMMIT;

-- ----------------------------
-- Table structure for t_selection
-- ----------------------------
DROP TABLE IF EXISTS `t_selection`;
CREATE TABLE `t_selection` (
  `selectID` int DEFAULT NULL,
  `courseID` int NOT NULL,
  `Sno` int NOT NULL,
  PRIMARY KEY (`Sno`,`courseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of t_selection
-- ----------------------------
BEGIN;
INSERT INTO `t_selection` VALUES (NULL, 2, 19022117);
INSERT INTO `t_selection` VALUES (NULL, 4, 19022117);
INSERT INTO `t_selection` VALUES (18, 6, 19022117);
INSERT INTO `t_selection` VALUES (NULL, 7, 19022117);
INSERT INTO `t_selection` VALUES (NULL, 1, 19032101);
INSERT INTO `t_selection` VALUES (23, 2, 19032101);
INSERT INTO `t_selection` VALUES (66, 7, 19032237);
COMMIT;

-- ----------------------------
-- Table structure for t_sinfo
-- ----------------------------
DROP TABLE IF EXISTS `t_sinfo`;
CREATE TABLE `t_sinfo` (
  `Sno` int NOT NULL,
  `Sname` varchar(5) DEFAULT NULL,
  `Ssex` varchar(2) DEFAULT NULL,
  `Smajor` varchar(10) DEFAULT NULL,
  `Stele` int DEFAULT NULL,
  PRIMARY KEY (`Sno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of t_sinfo
-- ----------------------------
BEGIN;
INSERT INTO `t_sinfo` VALUES (19022117, '王梦雪', '女', '计算机科学与技术', 23333);
INSERT INTO `t_sinfo` VALUES (19032101, '华金琳', '女', '计算机科学与技术', 66666);
INSERT INTO `t_sinfo` VALUES (19032237, '胡熠晖', '男', '计算机科学与技术', 18233);
COMMIT;

-- ----------------------------
-- Table structure for t_slogon
-- ----------------------------
DROP TABLE IF EXISTS `t_slogon`;
CREATE TABLE `t_slogon` (
  `Sno` int NOT NULL,
  `Spassword` int DEFAULT NULL,
  PRIMARY KEY (`Sno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of t_slogon
-- ----------------------------
BEGIN;
INSERT INTO `t_slogon` VALUES (19022117, 19022117);
INSERT INTO `t_slogon` VALUES (19032101, 19032101);
INSERT INTO `t_slogon` VALUES (19032237, 19032237);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
