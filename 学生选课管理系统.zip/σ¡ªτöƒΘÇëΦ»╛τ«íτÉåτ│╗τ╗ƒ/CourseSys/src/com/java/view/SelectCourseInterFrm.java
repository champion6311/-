

package com.java.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.LayoutStyle;
import javax.swing.table.DefaultTableModel;

import com.java.dao.CourseDao;
import com.java.dao.SelectionDao;
import com.java.model.Course;
import com.java.model.Selection;
import com.java.util.DbUtil;


//�γ�ѡ��
public class SelectCourseInterFrm extends JInternalFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//˽�г�Ա
	private JTable courseTable;
	private JScrollPane jScrollPane1;
	private JButton jb_confirm;
	private JButton jb_underFull;
	private int capacity;
	private int numSelected;
	private int courseId=-1;
	
	//�������ݿ�����
	DbUtil dbUtil = new DbUtil();
	CourseDao courseDao = new CourseDao();
	SelectionDao selectionDao = new SelectionDao();


	//���췽��
	public SelectCourseInterFrm() {
		initComponents();
		this.setLocation(200, 50);
		this.fillTable(new Course());

	}
	//���
	private void fillTable(Course course) {
		DefaultTableModel dtm = (DefaultTableModel) courseTable.getModel();
		dtm.setRowCount(0);
		//��������
		Connection con = null;
		try {
			con = dbUtil.getCon();
			ResultSet rs = courseDao.courseList(con, course);
			while (rs.next()) {
				Vector<String> v = new Vector<String>();
				v.add(rs.getString("courseId"));
				v.add(rs.getString("courseName"));
				v.add(rs.getString("courseTime"));
				v.add(rs.getString("courseTeacher"));
				v.add(rs.getString("capacity"));
				v.add(rs.getString("numSelected"));
				dtm.addRow(v);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	//�������
	private void initComponents() {

		jScrollPane1 = new javax.swing.JScrollPane();
		courseTable = new javax.swing.JTable();
		jb_underFull = new javax.swing.JButton();
		jb_confirm = new javax.swing.JButton();
		//��������
		setClosable(true);
		setIconifiable(true);
		setTitle("�γ�ѡ��");
		//����ʽ
		courseTable.setModel(new DefaultTableModel(
				new Object[][] {

				}, new String[] { "�γ̱��", "�γ�����", "�Ͽ�ʱ��", "�ο���ʦ", "�γ�����",
						"��ѡ����" }) {
			/**
							 * 
							 */
							private static final long serialVersionUID = 1L;
			boolean[] canEdit = new boolean[] { false, false, false, true,
					true, false };

			public boolean isCellEditable(int rowIndex, int columnIndex) {
				return canEdit[columnIndex];
			}
		});
		//��courseTable���Ӽ�����
		courseTable.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent evt) {
				courseTableMousePressed(evt);
			}
		});
		//��courseTable���ӵ����������
		jScrollPane1.setViewportView(courseTable);
		//��ť����
		jb_underFull
			.setText("ֻ��ʾδѡ���γ�");
		jb_underFull.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jb_underFullActionPerformed(evt);
			}
		});
		//ȷ��ѡ�ΰ�ť
		jb_confirm.setText("ȷ��ѡ��");
		jb_confirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jb_confirmActionPerformed(evt);
			}
		});

		//����GroupLayout���ֹ�����
		GroupLayout layout = new GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		//������ˮƽ��ȷ�������λ�úʹ�С
		layout
				.setHorizontalGroup(layout
						.createParallelGroup(
								GroupLayout.Alignment.LEADING)
						.addGroup(
								layout
										.createSequentialGroup()
										.addGroup(
												layout
														.createParallelGroup(
																GroupLayout.Alignment.LEADING)
														.addGroup(
																layout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				jScrollPane1,
																				GroupLayout.DEFAULT_SIZE,
																				578,
																				Short.MAX_VALUE))
														.addGroup(
																layout
																		.createSequentialGroup()
																		.addGap(
																				134,
																				134,
																				134)
																		.addComponent(
																				jb_underFull)
																		.addGap(
																				98,
																				98,
																				98)
																		.addComponent(
																				jb_confirm)))
										.addContainerGap()));
		//�����ش�ֱ��ȷ�������λ�úʹ�С
		layout
				.setVerticalGroup(layout
						.createParallelGroup(
								GroupLayout.Alignment.LEADING)
						.addGroup(
								layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(
												jScrollPane1,
												GroupLayout.PREFERRED_SIZE,
												319,
												GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												LayoutStyle.ComponentPlacement.RELATED,
												37, Short.MAX_VALUE)
										.addGroup(
												layout
														.createParallelGroup(
																GroupLayout.Alignment.BASELINE)
														.addComponent(
																jb_underFull)
														.addComponent(
																jb_confirm))
										.addContainerGap()));

		pack();//���ݷ��õ�����趨���ڵĴ�С��ʹ����ǡ���������е����
	}
	//��д�������ĸ�����
	private void jb_underFullActionPerformed(ActionEvent evt) {
		DefaultTableModel dtm = (DefaultTableModel) courseTable.getModel();
		dtm.setRowCount(0);
		Connection con = null;
		Course course=new Course();
		try {
			con = dbUtil.getCon();
			ResultSet rs = courseDao.UnderFullList(con, course);
			while (rs.next()) {
				Vector<String> v = new Vector<String>();
				v.add(rs.getString("courseId"));
				v.add(rs.getString("courseName"));
				v.add(rs.getString("courseTime"));
				v.add(rs.getString("courseTeacher"));
				v.add(rs.getString("capacity"));
				v.add(rs.getString("numSelected"));
				dtm.addRow(v);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	private void courseTableMousePressed(MouseEvent evt) {
		int row = courseTable.getSelectedRow();

		courseId = Integer.parseInt((String) courseTable.getValueAt(row, 0));
		capacity = Integer.parseInt((String) courseTable.getValueAt(row, 4));
		numSelected = Integer.parseInt((String) courseTable.getValueAt(row, 5));

	}

	private void jb_confirmActionPerformed(ActionEvent evt) {
		if (courseId==-1) {
			JOptionPane.showMessageDialog(this, "��ѡ��һ�ſγ̣�");
			return;
		}
		if (capacity == numSelected) {
			JOptionPane.showMessageDialog(this, "�ÿγ���ѡ��,��ѡ�������γ�.");
			return;
		}

		int n = JOptionPane.showConfirmDialog(this, "ȷ��Ҫѡ����ſγ���?");
		if (n == 0) {
			Connection con = null;
			int currentSno = LogOnFrm.currentStudent.getSno();
			Selection selection = new Selection(courseId, currentSno);
			try {
				con = dbUtil.getCon();
				int selectionNum = selectionDao.SelectionAdd(con, selection);
				int selectedNum = selectionDao.NumSelectedAdd(con, courseId);
				if (selectionNum == 1 && selectedNum == 1) {
					JOptionPane.showMessageDialog(this, "ѡ�γɹ�!");
					this.fillTable(new Course());
				} else {
					JOptionPane.showMessageDialog(this, "ѡ��ʧ��!");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				JOptionPane.showMessageDialog(this, "��ѡ�����ſγ�!");
			} finally {
				try {
					dbUtil.closeCon(con);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}




}