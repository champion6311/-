
package com.java.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;

import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

import com.java.dao.StudentDao;
import com.java.model.Student;
import com.java.util.DbUtil;
import com.java.util.StringUtil;

//�����޸�
public class PasswordModifyInterFrm extends JInternalFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//˽�г�Ա
	private JLabel jLabel1;
	private JLabel jLabel2;
	private JLabel jLabel3;
	private JButton jb_modify;
	private JButton jb_reset;
	private JPasswordField newPasswordTxt;
	private JPasswordField oldPasswordTxt;
	private JPasswordField passwordConfirmTxt;
	//��������
	DbUtil dbUtil = new DbUtil();
	StudentDao studentDao = new StudentDao();

	//���췽��
	public PasswordModifyInterFrm() {
		initComponents();
		this.setLocation(200, 50);
	}
	//�������
	private void initComponents() {

		jLabel1 = new JLabel();
		jLabel2 = new JLabel();
		jLabel3 = new JLabel();
		jb_modify = new JButton();
		jb_reset = new JButton();
		oldPasswordTxt = new JPasswordField();
		newPasswordTxt = new JPasswordField();
		passwordConfirmTxt = new JPasswordField();
		//���ô�������
		setClosable(true);//����Ϊ�ɹرյ�
		setIconifiable(true);//����Ϊ����С��һ��ͼ��
		setTitle("�����޸�");//���ñ���

		jLabel1.setText("ԭ����:");

		jLabel2.setText("������:");

		jLabel3.setText("������һ��������:");
		//��jb_modify��ť����ͼƬ���ı���������
		jb_modify.setIcon(new ImageIcon(this.getClass().getResource(
						"/com/java/view/image/modify.png")));
		jb_modify.setText("�޸�");
		jb_modify.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jb_modifyActionPerformed(evt);
			}
		});
		//��jb_reset��ť����ͼƬ���ı���������
		jb_reset.setIcon(new ImageIcon(this.getClass().getResource(
						"/com/java/view/image/reset.png")));
		jb_reset.setText("����");
		jb_reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jb_resetActionPerformed(evt);
			}
		});
		//����GroupLayout���ֹ�����
		GroupLayout layout = new GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		//������ˮƽ��ȷ�������λ�úʹ�С
		layout.setHorizontalGroup(layout
						.createParallelGroup(
								GroupLayout.Alignment.LEADING)
						.addGroup(
								layout
										.createSequentialGroup()
										.addGap(88, 88, 88)
										.addGroup(
												layout
														.createParallelGroup(
																GroupLayout.Alignment.LEADING)
														.addComponent(jLabel3)
														.addComponent(jLabel2)
														.addComponent(jLabel1)
														.addComponent(jb_modify))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												layout
														.createParallelGroup(
																GroupLayout.Alignment.TRAILING)
														.addComponent(
																newPasswordTxt,
																GroupLayout.PREFERRED_SIZE,
																152,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																passwordConfirmTxt,
																GroupLayout.PREFERRED_SIZE,
																152,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																oldPasswordTxt,
																GroupLayout.PREFERRED_SIZE,
																152,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(jb_reset))
										.addContainerGap(105, Short.MAX_VALUE)));
		//�����ش�ֱ��ȷ�������λ�úʹ�С
		layout.setVerticalGroup(layout
						.createParallelGroup(
								GroupLayout.Alignment.LEADING)
						.addGroup(
								layout
										.createSequentialGroup()
										.addGap(28, 28, 28)
										.addGroup(
												layout
														.createParallelGroup(
																GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel1)
														.addComponent(
																oldPasswordTxt,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addGap(28, 28, 28)
										.addGroup(
												layout
														.createParallelGroup(
																GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel2)
														.addComponent(
																newPasswordTxt,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addGap(18, 18, 18)
										.addGroup(
												layout
														.createParallelGroup(
																GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel3)
														.addComponent(
																passwordConfirmTxt,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
															    GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												41, Short.MAX_VALUE)
										.addGroup(
												layout
														.createParallelGroup(
																GroupLayout.Alignment.BASELINE)
														.addComponent(jb_modify)
														.addComponent(jb_reset))
										.addGap(25, 25, 25)));

		pack();//���ݷ��õ�����趨���ڵĴ�С��ʹ����ǡ���������е����
	}
	//��д�������ķ���
	private void jb_modifyActionPerformed(ActionEvent evt) {
		String oldPassword = new String(this.oldPasswordTxt.getPassword());
		String newPassword = new String(this.newPasswordTxt.getPassword());
		String passwordConfirm = new String(this.passwordConfirmTxt
				.getPassword());
		if (StringUtil.isEmpty(oldPassword)) {
			JOptionPane.showMessageDialog(this, "ԭ���벻��Ϊ��!");
			return;
		}
		if (StringUtil.isEmpty(newPassword)) {
			JOptionPane.showMessageDialog(this, "�����벻��Ϊ��!");
			return;
		}
		if (StringUtil.isEmpty(passwordConfirm)) {
			JOptionPane.showMessageDialog(this, "��������һ��������!");
			return;
		}
		String rightOldPassword = LogOnFrm.currentStudent.getSpassword();
		if (!oldPassword.equals(rightOldPassword)) {
			JOptionPane.showMessageDialog(this, "���������,����������!");
			return;
		}
		if (!newPassword.equals(passwordConfirm)) {
			JOptionPane.showMessageDialog(this, "�����벻һ��,����������!");
			return;
		}
		Connection con = null;
		int currentSno = LogOnFrm.currentStudent.getSno();
		Student student = new Student(currentSno, newPassword);

		try {
			con = dbUtil.getCon();
			int modifyNum = studentDao.PasswordModify(con, student);
			if (modifyNum == 1) {
				JOptionPane.showMessageDialog(this, "�޸ĳɹ�!");
				this.resetValue();

			} else {
				JOptionPane.showMessageDialog(this, "�޸�ʧ��!");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "�޸�ʧ��!");
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	 //���÷���
	private void resetValue() {
		this.oldPasswordTxt.setText("");
		this.newPasswordTxt.setText("");
		this.passwordConfirmTxt.setText("");
	}
	//������ð�ť���õķ���
	private void jb_resetActionPerformed(ActionEvent evt) {
		this.oldPasswordTxt.setText("");
		this.newPasswordTxt.setText("");
		this.passwordConfirmTxt.setText("");
	}





}